from . import synth
from . import line_data
import pkg_resources

package_path = pkg_resources.resource_filename('pymoog', '')